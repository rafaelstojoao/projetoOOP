/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.copa;


public class Copa {

    public static void main(String[] args) {
        Partida partida = new Partida();
        
        
    }   
               
}
