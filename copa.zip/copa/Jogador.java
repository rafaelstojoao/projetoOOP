/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.copa;


public class Jogador extends Pessoa{
        public int numero;
        public String posicao;
        public int numCartoesAmarelos;
        public int numCartoesVermelhos;
        public int numGols;
}
