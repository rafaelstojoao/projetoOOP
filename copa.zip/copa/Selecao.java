/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.copa;
import java.util.ArrayList;

public class Selecao {
    
    public String nome;
    public ArrayList<Jogador> jogador = new ArrayList<Jogador>();
    public int titulos;
    public Pessoa tecnico = new Pessoa();
    public ArrayList<Comissao_Tecnica> comissao_tecnica = new ArrayList<Comissao_Tecnica>();
    
    
}
