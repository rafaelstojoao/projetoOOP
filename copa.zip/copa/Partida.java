/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.copa;
import java.util.Date;
import java.util.Scanner;


public class Partida {
        
        public int opcao = 0;
        Scanner input = new Scanner(System.in);
        public Selecao mandante = new Selecao();
        public Selecao visitante = new Selecao();
        public int golsMandante;
        public int golsVisitante;
        public String relatorio;
        public Local localPartida = new Local();
        public Date dataPartida = new Date();
        
        
        
        
        
        // Funções
       public void iniciarPartida(){
        System.out.println("Começa a partida");
       }
       
    /**
     *
     * @param mandante
     * @param visitante
     */
    public void registraFalta(String mandante, String visitante){
            System.out.println("Qual time recebeu a falta?");
            System.out.println("[1] Time Mandante");
            System.out.println("[2] Time Visitante");
            
            opcao = Integer.parseInt(input.nextLine());
            
            if (opcao == 1){
                System.out.println("O time Mandante recebe uma falta!");
            }
            else{
                System.out.println("O time Visitante recebe uma falta!");
            }
       }
               
}
